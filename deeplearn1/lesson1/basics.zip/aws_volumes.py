
from aws_base import *
from aws_util import *

"""
List of block device counts based on http://ec2instances.info
"""
ephemeral_counts = {
    'c1.medium': 1, 'c1.xlarge': 4,
    'c3.large': 2, 'c3.xlarge': 2, 'c3.2xlarge': 2, 'c3.4xlarge': 2, 'c3.8xlarge': 2,
    'c4.large': 0, 'c4.xlarge': 0, 'c4.2xlarge': 0, 'c4.4xlarge': 0, 'c4.8xlarge': 0,
    'cc2.8xlarge': 4,
    'cg1.4xlarge': 2,
    'cr1.8xlarge': 2,
    'd2.xlarge': 3, 'd2.2xlarge': 6, 'd2.4xlarge': 12, 'd2.8xlarge': 14,
    'g2.2xlarge': 1, 'g2.8xlarge': 2,
    'hi1.4xlarge': 2,
    'hs1.8xlarge': 24,
    'i2.xlarge': 1, 'i2.2xlarge': 2, 'i2.4xlarge': 4, 'i2.8xlarge': 8,
    'm1.small': 1, 'm1.medium': 1, 'm1.large': 2, 'm1.xlarge': 4,
    'm2.xlarge': 1, 'm2.2xlarge': 1, 'm2.4xlarge': 2,
    'm3.medium': 1, 'm3.large': 1, 'm3.xlarge': 1, 'm3.2xlarge': 2,
    'm4.large': 0, 'm4.xlarge': 0, 'm4.2xlarge': 0, 'm4.4xlarge': 0, 'm4.10xlarge': 0, 'm4.16xlarge': 0,
    'p2.xlarge': 0, 'p2.8xlarge': 0, 'p2.16xlarge': 0,
    'r3.large': 1, 'r3.xlarge': 1, 'r3.2xlarge': 1, 'r3.4xlarge': 1, 'r3.8xlarge': 2,
    'r4.large': 0, 'r4.xlarge': 0, 'r4.2xlarge': 0, 'r4.4xlarge': 0, 'r4.8xlarge': 0, 'r4.16xlarge': 0,
    't1.micro': 0,
    't2.nano': 0, 't2.micro': 0, 't2.small': 0, 't2.medium': 0, 't2.large': 0,
    'x1.16xlarge': 1, 'x1.32xlarge': 2
}

"""
Utility method which returns block storage.
"""
def get_block_devices(image_id, instance_type, volume_size):
    root_devices = aws(
        'ec2', 'describe-images', '--image-ids', image_id, '--query',
        'Images[].RootDeviceName')

    block_devices = [
        {
            'DeviceName': root_devices[0],
            'Ebs': {
                'VolumeSize': volume_size,
                'DeleteOnTermination': True,
                'VolumeType': 'gp2'
            }
        }
    ]

    for i in range(0, ephemeral_counts[instance_type]):
        ephemeral_device = {
          "DeviceName": "/dev/sd%s" % chr(ord('a') + i + 1),
          "VirtualName": "ephemeral%d" % i,
        }

        block_devices.append(ephemeral_device)

    return block_devices

"""
Utility method which mounts all available volumes.
"""
def extra_storage(user_name, host_names):
    run_script(user_name, host_names, 'extra_storage.sh')

"""
Utility method which creates a swap partition of the specified size.
"""
def enable_swap(user_name, host_names, swap_size):
    with open('awscli/swapsize.txt', 'w') as swapsize_file:
        swapsize_file.write(str(swap_size))

    upload_file(user_name, host_names, 'awscli/swapsize.txt')
    run_script(user_name, host_names, 'enable_swap.sh')

