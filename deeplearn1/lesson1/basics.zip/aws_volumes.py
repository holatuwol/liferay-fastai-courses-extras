
from aws_base import *
from aws_util import *

"""
Utility method which returns block storage.
"""
def get_block_devices(image_id, instance_type, volume_size):
    image_info = aws(
        'ec2', 'describe-images', '--image-ids', image_id, '--query',
        'Images[0]')

    root_devices = [
        {
            'DeviceName': image_info['RootDeviceName'],
            'Ebs': {
                'VolumeSize': volume_size,
                'DeleteOnTermination': True,
                'VolumeType': 'gp2'
            }
        }
    ]

    instance_types = get_instance_types()
    ephemeral_mappings = image_info['BlockDeviceMappings'][1:]
    instance_types = get_instance_types()

    ephemeral_count = instance_types[0]['storage']['devices']

    ephemeral_devices = [
        {
          "DeviceName" : mapping['DeviceName'],
          "VirtualName" : mapping['VirtualName']
        }
        for mapping in ephemeral_mappings[0:ephemeral_count]
    ]

    return root_devices + ephemeral_devices

"""
Utility method which mounts all available volumes.
"""
def extra_storage(user_name, host_names):
    run_script(user_name, host_names, 'extra_storage.sh')

"""
Utility method which creates a swap partition of the specified size.
"""
def enable_swap(user_name, host_names, swap_size):
    with open('awscli/swapsize.txt', 'w') as swapsize_file:
        swapsize_file.write(str(swap_size))

    upload_file(user_name, host_names, 'awscli/swapsize.txt')
    run_script(user_name, host_names, 'enable_swap.sh')

