
from aws_base import *
from aws_util import *
from IPython.utils.py3compat import *
from netaddr import IPAddress, IPNetwork
import os

security_group_names = ['default']

"""
Utility method to retrieve the group that matches the specified group name.
"""
def get_security_group(group_name):
    return get_security_groups([group_name])

"""
Utility method to retrieve the groups that matches the specified group names.
"""
def get_security_groups(group_names):
    security_groups_json = aws('ec2', 'describe-security-groups')
    security_groups = security_groups_json['SecurityGroups']

    candidate_groups = {}

    for security_group in security_groups:
        security_group_name = security_group['GroupName']
        if security_group_name in group_names:
            candidate_groups[security_group_name] = security_group

    return candidate_groups

security_groups = get_security_groups(security_group_names)

assert set(security_groups.keys()) == set(security_group_names)

internal_security_group_name = 'default'

internal_group = security_groups[internal_security_group_name]
internal_group_id = internal_group['GroupId']
internal_group_user_id = internal_group['OwnerId']

is_cluster_communication_enabled = False

for permission in internal_group['IpPermissions']:
    if 'FromPort' not in permission or 'ToPort' not in permission:
        continue

    if permission['FromPort'] != 0 or permission['ToPort'] != 65535:
        continue

    for user_id_group_pair in permission['UserIdGroupPairs']:
        if user_id_group_pair['GroupId'] != internal_group_id:
            continue

        if user_id_group_pair['UserId'] != internal_group_user_id:
            continue

        is_cluster_communication_enabled = True

if not is_cluster_communication_enabled:
    aws(
        'ec2', 'authorize-security-group-ingress',
        '--group-name', internal_security_group_name,
        '--protocol', 'tcp', '--port', '0-65535',
        '--source-group', internal_group_id,
        '--group-owner', internal_group_user_id)

    updated_security_groups = get_security_group(internal_security_group_name)
    internal_group = updated_security_groups[internal_security_group_name]
    security_groups[internal_security_group_name] = internal_group

external_security_group_name = 'default'
assume_ssh_tunnel = True

external_group = security_groups[external_security_group_name]

is_external_communication_enabled = False

external_ip_address_string = check_output(['curl', '-s', 'http://ipinfo.io/ip'])
external_ip_address = IPAddress(external_ip_address_string)

for security_group in security_groups.values():
    for permission in security_group['IpPermissions']:
        if 'FromPort' not in permission or 'ToPort' not in permission:
            continue

        allow_ssh_port = permission['FromPort'] >= 22 and permission['ToPort'] <= 22
        allow_all_ports = permission['FromPort'] == 0 and permission['ToPort'] == 65535

        if not (assume_ssh_tunnel and allow_ssh_port) and not allow_all_ports:
            continue

        for ip_range in permission['IpRanges']:
            ip_network_string = ip_range['CidrIp']
            ip_network = IPNetwork(ip_network_string)

            if external_ip_address in ip_network:
                is_external_communication_enabled = True

if not is_external_communication_enabled:
    if assume_ssh_tunnel:
        port_range = '22'
    else:
        port_range = '0-65535'

    aws(
        'ec2', 'authorize-security-group-ingress',
        '--group-name', external_security_group_name,
        '--protocol', 'tcp', '--port', port_range,
        '--cidr', external_ip_address_string + '/32')

    updated_security_groups = get_security_group(external_security_group_name)
    external_group = updated_security_groups[external_security_group_name]
    security_groups[external_security_group_name] = external_group

