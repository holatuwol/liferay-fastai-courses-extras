
from __future__ import print_function
from aws_base import *
import json
import os
import subprocess

user_name = None

try:
    user_json = aws('iam', 'get-user')
    user = user_json['User']
    user_name = user['UserName']
except:
    print('Insufficient IAM privileges')

user_name

aws_regions_json = aws('ec2', 'describe-regions')
aws_regions = aws_regions_json['Regions']
region_names = [aws_region['RegionName'] for aws_region in aws_regions]

assert region in region_names

iam_role_name = 'TRAIN_EC2_DefaultRole'

instance_profile_arn = None
iam_role_arn = None

if user_name is not None:
    instance_profile_json = aws(
        'iam', 'get-instance-profile', '--instance-profile-name', iam_role_name)

    instance_profile = instance_profile_json['InstanceProfile']

    instance_profile_arn = instance_profile['Arn']
    iam_role_arn = instance_profile['Roles'][0]['Arn']

[instance_profile_arn, iam_role_arn]

if user_name is not None:
    policy_info = {
        'Version': '2012-10-17',
        'Statement': [
            {
                'Effect': 'Allow',
                'Action': [ 'iam:PassRole' ],
                'Resource': [ str(iam_role_arn) ]
            },
            {
                'Effect': 'Allow',
                'Action': [ 'iam:AddRoleToInstanceProfile' ],
                'Resource': [ str(instance_profile_arn) ]
            }
        ]
    }

