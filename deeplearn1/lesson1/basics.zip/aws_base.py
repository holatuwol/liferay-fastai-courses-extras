
from IPython.utils.py3compat import *
import json
import os
import requests
import subprocess
import sys

if os.name == 'nt':
    subprocess.call(['assoc', '.py=py_auto_file'])
    subprocess.call(['ftype', 'py_auto_file="%s"' % sys.executable, '"%1"', '%*'])

region = subprocess.check_output(['aws', 'configure', 'get', 'region']).strip()
region = bytes_to_str(region)
region

"""
Utility method which allows us to invoke AWS without magic commands.
"""
def aws(*args):
    command = ['aws'] + [str(x) for x in args]
    output = subprocess.check_output(command)

    try:
        return json.loads(bytes_to_str(output))
    except:
        return None

image_types = {
    'ubuntu18': {
        'hvm': 'ubuntu/images/hvm-ssd/ubuntu-bionic-18.04-amd64-server-20190116'
    },
    'ubuntu16': {
        'hvm': 'ubuntu/images/hvm-ssd/ubuntu-xenial-16.04-amd64-server-20181223',
        'paravirtual': 'ubuntu/images/ebs-ssd/ubuntu-xenial-16.04-amd64-server-20181223'
    },
    'ubuntu14': {
        'paravirtual': 'ubuntu/images/ebs-ssd/ubuntu-trusty-14.04-amd64-server-20190110',
        'hvm': 'ubuntu/images/hvm-ssd/ubuntu-trusty-14.04-amd64-server-20190110'
    },
    'amazon1': {
        'paravirtual': 'amzn-ami-pv-2018.03.0.20181129-x86_64-ebs',
        'hvm': 'amzn-ami-hvm-2018.03.0.20181129-x86_64-gp2'
    },
    'amazon2': {
        'hvm': 'amzn2-ami-hvm-2.0.20190115-x86_64-gp2'
    },
    'redhat': {
        'paravirtual': 'RHEL-6.5_GA-20140929-x86_64-11-Hourly2-GP2',
        'hvm': 'RHEL-7.6_HVM_GA-20181017-x86_64-0-Hourly2-GP2'
    },
    'suse15': {
        'hvm': 'suse-sles-15-v20180816-hvm-ssd-x86_64'
    },
    'suse11': {
        'hvm': 'suse-sles-11-sp4-v20180104-hvm-ssd-x86_64'
    },
    'windows': {
        'hvm': 'Windows_Server-2019-English-Full-Base-2019.01.10'
    }
}

image_types['amazon'] = image_types['amazon2']
image_types['suse'] = image_types['suse15']
image_types['ubuntu'] = image_types['ubuntu18']

def get_default_image_id(virtualization_type, linux_type='ubuntu'):
    if linux_type not in image_types:
        error_notes = (linux_type, ', '.join(image_types.keys()))
        raise ValueError('%s is not an available operating system (%s)' % error_notes)

    linux_image_types = image_types[linux_type]

    if virtualization_type not in linux_image_types:
        error_notes = (image_type, linux_type, ', '.join(linux_image_types.keys()))
        raise ValueError('%s is not an available virtualization for operating system %s (%s)' % error_keys)

    image_name = linux_image_types[virtualization_type]

    default_ami_json = aws('ec2', 'describe-images', '--filters', 'Name=name,Values=' + image_name)

    default_image = default_ami_json['Images'][0]
    return default_image['ImageId']

instance_types = None

"""
Retrieve the instance types data from ec2instances.info
"""
def get_instance_types():
    global instance_types
    if instance_types is not None:
        return instance_types

    metadata_url = 'https://github.com/powdahound/ec2instances.info/raw/master/www/instances.json'

    instance_file = requests.get(metadata_url)
    instance_types = json.loads(instance_file.text)

    return instance_types

def get_virtualization_type(check_instance_type, default_virtualization_type = 'hvm'):
    for instance_type in get_instance_types():
        if instance_type['instance_type'] != check_instance_type:
            continue

        supported_virtualization_types = instance_type['linux_virtualization_types']

        if default_virtualization_type == 'paravirtual' and 'PV' in supported_virtualization_types:
            return default_virtualization_type

        if default_virtualization_type == 'hvm' and 'HVM' in supported_virtualization_types:
            return default_virtualization_type

        if 'HVM' in supported_virtualization_types:
            return 'hvm'

        if 'PV' in supported_virtualization_types:
            return 'paravirtual'

    return None

