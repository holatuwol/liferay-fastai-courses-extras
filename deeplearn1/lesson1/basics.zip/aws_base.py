
from IPython.utils.py3compat import *
import json
import os
import subprocess
import sys

if os.name == 'nt':
    subprocess.call(['assoc', '.py=py_auto_file'])
    subprocess.call(['ftype', 'py_auto_file="%s"' % sys.executable, '"%1"', '%*'])

region = subprocess.check_output(['aws', 'configure', 'get', 'region']).strip()
region = bytes_to_str(region)
region

"""
Utility method which allows us to invoke AWS without magic commands.
"""
def aws(*args):
    command = ['aws'] + [str(x) for x in args]
    output = subprocess.check_output(command)

    try:
        return json.loads(bytes_to_str(output))
    except:
        return None

image_types = {
    'ubuntu': {
        'paravirtual': 'ubuntu/images/ebs-ssd/ubuntu-xenial-16.04-amd64-server-20160907.1',
        'hvm': 'ubuntu/images/hvm-ssd/ubuntu-xenial-16.04-amd64-server-20160907.1'
    },
    'amazon': {
        'paravirtual': 'amzn-ami-pv-2016.09.0.20160923-x86_64-ebs',
        'hvm': 'amzn-ami-hvm-2016.09.0.20160923-x86_64-gp2'
    },
    'redhat': {
        'hvm': 'RHEL-7.2_HVM_GA-20151112-x86_64-1-Hourly2-GP2',
    },
    'suse': {
        'hvm': 'suse-sles-12-sp1-v20151215-hvm-ssd-x86_64'
    }
}

def get_default_image_id(virtualization_type, linux_type='ubuntu'):
    if linux_type not in image_types:
        error_notes = (linux_type, ', '.join(image_types.keys()))
        raise ValueError('%s is not an available operating system (%s)' % error_notes)

    linux_image_types = image_types[linux_type]

    if virtualization_type not in linux_image_types:
        error_notes = (image_type, linux_type, ', '.join(linux_image_types.keys()))
        raise ValueError('%s is not an available virtualization for operating system %s (%s)' % error_keys)

    image_name = linux_image_types[virtualization_type]

    default_ami_json = aws('ec2', 'describe-images', '--filters', 'Name=name,Values=' + image_name)

    default_image = default_ami_json['Images'][0]
    return default_image['ImageId']

unavailable_instance_families = {
    'paravirtual': ['t2', 'm4', 'c4', 'cc2', 'g2', 'r3', 'cr1', 'd2', 'i2'],
    'hvm': ['m1', 'c1', 'm2']
}

def get_virtualization_type(instance_type, default_value = 'hvm'):
    instance_family = instance_type[:instance_type.find('.')]

    if instance_family in unavailable_instance_families['paravirtual']:
        return 'hvm'
    elif instance_family in unavailable_instance_families['hvm']:
        return 'paravirtual'
    else:
        return default_value

