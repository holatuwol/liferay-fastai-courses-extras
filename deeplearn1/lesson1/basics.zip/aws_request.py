
from __future__ import print_function
from aws_util import *
import json
import os
import re
import requests
import time

"""
Base class to use for EC2 instance requests.
"""
class InstanceRequest(object):

    """
    Provide a place for us to store an active spot request.
    """
    def __init__(self, prefix):
        self.specification_file_name = 'awscli/%s_specification.json' % prefix
        self.response_file_name = 'awscli/%s_response.json' % prefix
        self.fulfilled_file_name = 'awscli/%s_instances.json' % prefix

    """
    Retrieve the specification used during the last request.
    """
    def get_specification(self):
        if not os.path.isfile(self.specification_file_name):
            return None

        with open(self.specification_file_name, 'r') as specification_file:
            return json.load(specification_file)

    """
    Retrieve the last cached response.
    """
    def get_response(self):
        if not os.path.isfile(self.response_file_name):
            return None

        with open(self.response_file_name, 'r') as response_file:
            return json.load(response_file)

    """
    Retrieve the list of known EC2 instances corresponding to this request.
    """
    def get_fulfilled(self):
        if not os.path.isfile(self.fulfilled_file_name):
            return None

        with open(self.fulfilled_file_name, 'r') as fulfilled_file:
            return json.load(fulfilled_file)

    """
    Request a cluster. If there is already an active cluster that is stored in
    the cache file, it will assume the request was already made and will await
    its fulfillment.
    """
    def request(self, bid_price, cluster_size, specification):

        # Save the specification request

        with open(self.specification_file_name, 'w') as specification_file:
            json.dump(specification, specification_file, indent = 2)

        # Check for a pre-existing response to a request and only issue a
        # request if the pre-existing response does not exist.

        response = self.get_response()

        if response is None:
            response = self.make_request(bid_price, cluster_size)

            with open(self.response_file_name, 'w') as response_file:
                json.dump(response, response_file)

        # Wait for the instances to all be running

        requested_instance_ids = self.get_instance_ids(response)
        pending_instances = self.get_instances(
            requested_instance_ids, 'pending')

        while len(pending_instances) != 0:
            print('Waiting for instances to start...')
            time.sleep(15)
            pending_instances = self.get_instances(
                requested_instance_ids, 'pending')

        running_instances = self.get_instances(
            requested_instance_ids, 'running')

        with open(self.fulfilled_file_name, 'w') as fulfilled_file:
            json.dump(running_instances, fulfilled_file, indent = 2)

        # Register running instances in known_hosts file

        print('%d instances started' % len(running_instances))

        for instance in running_instances:
            self.add_known_host(instance)

    """
    Utility method to check on instance IDs.
    """
    def get_instances(self, instance_ids, state_name):

        if len(instance_ids) == 0:
            return []

        # Retrieve all listed instances

        reservations_json = aws(
            'ec2', 'describe-instances', '--instance-ids',
            *instance_ids)

        # Filter down to instances with the specified state

        instances = []
        reservations = reservations_json['Reservations']

        for reservation in reservations:
            for instance in reservation['Instances']:
                if instance['State']['Name'] == state_name:
                    instances.append(instance)

        # Sort the instances by launch time

        instances = sorted(
            instances,
            key = lambda instance: instance['LaunchTime'])

        return instances

    """
    Add the given host's ECDSA to the known_hosts file by extracting the ECDSA
    fingerprint.
    """
    def add_known_host(self, instance):
        host_name = instance['PublicDnsName']

        # We could extract the ECDSA fingerprint from the console output, but
        # the console output can be blank. Rather than rely on console output,
        # we'll be insecure and simply trust the server.

        while not is_known_host(host_name):
            subprocess.call([
                'ssh', '-o', 'StrictHostKeyChecking=no', host_name, 'echo'
            ])

            time.sleep(5)

        print('%s added to known hosts' % host_name)

on_demand_prices = None

"""
Update the on-demand prices for Linux instances based on data contained in a URL.
"""
def get_instance_types(price_path):
    global region

    price_url = 'http://a0.awsstatic.com/pricing/1/ec2/%s' % price_path

    price_file = requests.get(price_url)
    price_string = price_file.text

    # Convert the Javascript object into JSON notation for parsing

    price_js_string = price_string[price_string.find('{'):price_string.rfind('}')+1]
    price_json_string = re.sub(r'([^,\\{]*):', '"\\1\":', price_js_string)
    price_json = json.loads(price_json_string)

    # Retrieve the data specific for the current region

    region_data = [
        data for data in price_json['config']['regions']
            if data['region'] == region
    ]

    assert len(region_data) == 1

    return region_data[0]['instanceTypes']

"""
Return the on-demand prices for Linux instances in the user's region.
"""
def get_on_demand_prices():
    global on_demand_prices

    # If we've already built it up once, then we don't have to rebuild

    if on_demand_prices is not None:
        return on_demand_prices

    # Load the Linux on-demand instance pricing

    on_demand_prices = {}

    # Extract the pricing data for current generation models

    current_generation_types = get_instance_types('linux-od.min.js')

    for instance_category in current_generation_types:
        for size_data in instance_category['sizes']:
            instance_size = size_data['size']

            demand_price = float(
                size_data['valueColumns'][0]['prices']['USD'])

            on_demand_prices[instance_size] = demand_price

    # Extract the pricing data for previous generation models

    previous_generation_types = get_instance_types(
        'previous-generation/ri-v2/linux-unix-shared.min.js')

    for instance_category in previous_generation_types:
        instance_size = instance_category['type']

        term_data = instance_category['terms'][0]

        demand_price = float(
            term_data['onDemandHourly'][0]['prices']['USD'])

        on_demand_prices[instance_size] = demand_price

    # Return the pricing data

    return on_demand_prices

"""
Extension of an InstanceRequest which works with on-demand instance requests.
"""
class OnDemandInstanceRequest(InstanceRequest):

    """
    Issues a request for on-demand instances with the given number of cluster
    nodes. The bid price will be ignored.
    """
    def make_request(self, bid_price, cluster_size):
        return aws(
            'ec2', 'run-instances', '--count', cluster_size,
            '--cli-input-json', 'file://' + self.specification_file_name)

    """
    Retrieve the instance IDs that are associated with the given response.
    """
    def get_instance_ids(self, response):
        return [instance['InstanceId'] for instance in response['Instances']]

