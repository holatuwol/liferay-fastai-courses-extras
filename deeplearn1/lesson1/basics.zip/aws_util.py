
from __future__ import print_function
from aws_base import *
from IPython.utils.py3compat import *
import os
import pysftp
import requests
import subprocess

private_key_name = 'mdang-training-shared'
private_key_location = '~/Dropbox/Amazon/mdang-training-shared.pem'

private_key_location = os.path.expanduser(private_key_location)
assert private_key_location is not None and os.path.isfile(private_key_location)

private_key_json = aws(
    'ec2', 'describe-key-pairs', '--key-names', private_key_name)

private_keys = None

if private_key_json is not None:
    private_keys = private_key_json['KeyPairs']

if not os.path.isdir('awscli'):
    os.mkdir('awscli')

if not os.path.isdir('output'):
    os.mkdir('output')

if not os.path.isdir('scripts'):
    os.mkdir('scripts')

"""
Utility method which calls subprocess.check_output and wraps the result
in bytes_to_str() and strips the extra whitespace
"""
def check_output(args):
    return bytes_to_str(subprocess.check_output(args)).strip()

"""
Utility method to determine if the host is registered in the known_hosts file.
Uses ssh-keygen directly to determine this.
"""
def is_known_host(host_name):
    is_known_host_name = subprocess.call(['ssh-keygen', '-F', host_name])
    return is_known_host_name == 0

"""
Utility method to add a known host to the known_hosts file.
"""
def add_known_host(host_name, key_type, key_value):
    remove_known_host(host_name)

    with open(os.path.expanduser('~/.ssh/known_hosts'), 'a') as known_hosts:
        known_hosts.write('%s %s %s' % (host_name, key_type, key_value))

    print('%s added as known host' % host_name)

"""
Utility method to remove a known host from the known_hosts file.
"""
def remove_known_host(host_name):
    if is_known_host(host_name):
        subprocess.call(['ssh-keygen', '-R', host_name])
        print('%s removed from known hosts' % host_name)

instance_types = None

"""
Retrieve the instance types data from ec2instances.info
"""
def get_instance_types():
    metadata_url = 'https://github.com/powdahound/ec2instances.info/raw/master/www/instances.json'

    instance_file = requests.get(metadata_url)
    instance_types = json.loads(instance_file.text)

    return instance_types

"""
Utility method which uploads the given file via sFTP or S3 depending on size.
"""
def upload_file(user_name, host_names, source_file_name, target_file_name = None):
    file_size = os.path.getsize(source_file_name)

    if target_file_name is None:
        target_file_name = os.path.basename(source_file_name)

    if file_size < 1024 * 1024:
        upload_file_sftp(user_name, host_names, source_file_name, target_file_name)
    else:
        upload_file_s3(user_name, host_names, source_file_name, target_file_name)

"""
Utility method which uploads the given file via sFTP to multiple servers.
"""
def upload_file_sftp(user_name, host_names, source_file_name, target_file_name):
    global private_key_location

    print('Uploading %s to %d servers' % (source_file_name, len(host_names)))

    for host_name in host_names:
        if not is_known_host(host_name):
            print('%s is not a known host' % host_name)
            continue

        with pysftp.Connection(
            host_name, username = user_name,
            private_key = private_key_location) as sftp:

            sftp.put(source_file_name, target_file_name)

"""
Utility method which copies a file to an S3 bucket (with a mostly-unique ID) and
downloads the file onto multiple servers. Optionally can be used to upload a
file to S3 but not to any servers by passing an empty list of host names.
"""

def upload_file_s3(user_name, host_names, source_file_name, target_file_name):
    with open('awscli/bucket.txt', 'r') as bucket_file:
        bucket_name = bucket_file.read().strip()

    target_file_path = 's3://%s/%s' % (bucket_name, target_file_name)

    if host_names is not None and len(host_names) > 0:
        local_host_name = check_output(['hostname', '-s'])
        local_timestamp = check_output(['date', '+%s'])

        suffix = '.' + local_host_name + '.' + local_timestamp
        target_file_path += suffix

    aws('s3', 'cp', source_file_name, target_file_path)

    if host_names is None or len(host_names) == 0:
        return

    script_file_name = 'download_from_s3.sh'

    with open('scripts/' + script_file_name, 'w') as script_file:
        script_file.write('#!/bin/bash\n')
        script_file.write('source ~/.profile\n')
        script_file.write('aws s3 cp %s %s' % (target_file_path, target_file_name))

    run_script(user_name, host_names, script_file_name)
    aws('s3', 'rm', target_file_path)

"""
Utility method which uploads a file in the scripts folder to multiple servers
and prepares a script that will run it on all servers.
"""
def run_script(user_name, host_names, script_name):
    global private_key_location

    upload_file(user_name, host_names, 'scripts/' + script_name)

    with open('scripts/run_script.sh', 'w') as script_file:
        for host_name in host_names:
            if not is_known_host(host_name):
                print('%s is not a known host' % host_name)
                continue

            # Ensure that the file has execute permissions on the host

            script_file.write('ssh -i %s %s@%s "chmod u+x %s"\n' %                 (private_key_location, user_name, host_name, script_name))

            # Execute the script on the host, but log to a local file to avoid
            # filling up the notebook with text. Also run each script in the
            # background since the nodes do not depend on each other.

            output_log = 'output/' + script_name + '.' + host_name + '.log'

            script_file.write('ssh -i %s %s@%s "./%s" > %s 2>&1 &\n' %                 (private_key_location, user_name, host_name, script_name, output_log))

        # Wait for all background processes to finish.

        script_file.write('wait\n')

    print('Executing %s on %d servers' % (script_name, len(host_names)))

    subprocess.call(['chmod', 'u+x', 'scripts/run_script.sh'])
    subprocess.call('scripts/run_script.sh', shell = True)

    print('Completed %s on %d servers' % (script_name, len(host_names)))

"""
Utility method which creates an of the specified folder and uploads it to
all servers using the same name as the folder.
"""
def upload_archive(user_name, host_names, source_folder_name):
    archive_name = os.path.basename(source_folder_name) + '.tar.gz'
    subprocess.call(['tar', '-acf', archive_name, source_folder_name])
    upload_file(user_name, host_names, archive_name)
    os.remove(archive_name)

"""
Utility method which installs AWS CLI on all machines and configures its default
region to be the same as the region for the local machine.
"""
def install_awscli(user_name, host_names):
    global region

    with open('awscli/region.txt', 'w') as region_file:
        region_file.write(region)

    upload_file(user_name, host_names, 'awscli/region.txt')
    run_script(user_name, host_names, 'install_awscli.sh')

"""
Utility method which sets an environment variable specifying a bucket which can
be referenced in other scripts.
"""
def set_bucket(user_name, host_names, bucket_name):
    global region

    bucket_url = 'http://s3-%s.amazonaws.com/%s/' % (region, bucket_name)
    check_bucket_url = check_output(['curl', '-s', bucket_url])

    if check_bucket_url.find('PermanentRedirect') != -1:
        print('Bucket is not in region %s')

    with open('awscli/bucket.txt', 'w') as bucket_file:
        bucket_file.write(bucket_name)

    upload_file(user_name, host_names, 'awscli/bucket.txt')
    run_script(user_name, host_names, 'set_bucket.sh')

