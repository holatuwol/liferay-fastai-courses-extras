#!/bin/bash

SWAP_SIZE=$(head -1 swapsize.txt)

for swapdisk in $(/sbin/swapon -s | grep -F '/dev' | cut -d' ' -f 1); do
    sudo /sbin/swapoff $swapdisk
done

echo "Creating ${SWAP_SIZE}g swap partition"

# Make sure that everything persists across restarts.

echo '#!/bin/bash' | sudo tee /etc/rc2.d/S01enable_swap
echo "SWAP_SIZE=$SWAP_SIZE" | sudo tee -a /etc/rc2.d/S01enable_swap

echo 'case "$1" in
start)
    mkdir /var/lock/subsys 2>/dev/null
    touch /var/lock/subsys/listener

    # Add designated amount of swap space
    # stackoverflow.com/questions/17173972/how-do-you-add-swap-to-an-ec2-instance

    if [ "" == "$(/sbin/swapon -s)" ]; then
        if [ ! -f /mnt/swapfile ]; then
            sudo dd if=/dev/zero of=/mnt/swapfile bs=1G seek=0 count=$SWAP_SIZE
            sudo chmod og-rw /mnt/swapfile
            sudo /sbin/mkswap /mnt/swapfile
        fi

        sudo /sbin/swapon /mnt/swapfile
    fi ;;
*)
    echo error
    exit 1 ;;
esac' | sudo tee -a /etc/rc2.d/S01enable_swap

# Run the same script that will be run on startup.

sudo chmod a+rwx /etc/rc2.d/S01enable_swap
sudo /etc/rc2.d/S01enable_swap start