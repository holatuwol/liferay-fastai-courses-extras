#!/bin/bash

VOLUMES=$(lsblk | grep -v '/$' | sed -n '2,$p' | cut -d' ' -f 1)
INSTANCE_TYPE=$(curl -s http://169.254.169.254/latest/meta-data/instance-type)

sudo umount /mnt

echo $INSTANCE_TYPE

NEW_MNT=

if [ "" != "$VOLUMES" ]; then
    for volume in $VOLUMES; do
        echo $volume

        if [ "" == "$(sudo file -s /dev/$volume | grep -i '\(linux\|boot\)')" ]; then
            sudo mkfs -t ext4 /dev/$volume
        fi

        sudo mkdir -p /$volume
        sudo mount /dev/$volume /$volume

        if [ "" == "$NEW_MNT" ] && [ "" == "$(sudo file -s /dev/$volume | grep -iF boot)" ]; then
            sudo mount --bind /$volume /mnt
            NEW_MNT=$volume
        fi
    done
fi