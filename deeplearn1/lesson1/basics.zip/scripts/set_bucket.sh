#!/bin/bash

touch $HOME/.profile

S3_BUCKET=$(cat bucket.txt)
echo >> $HOME/.profile
echo "# Added for AWS CLI" >> $HOME/.profile
echo "export S3_BUCKET=$S3_BUCKET" >> $HOME/.profile