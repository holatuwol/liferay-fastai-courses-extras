#!/bin/bash

if [ "" != "$(uname -a | grep Ubuntu)" ]; then
    # Add mirror to avoid slow downloads

    APT_MIRROR="mirror://mirrors.ubuntu.com/mirrors.txt"
    APT_REPOSITORIES="main restricted universe multiverse"

    #sudo sed -i -e "s@[^ ]*ec2.archive.ubuntu.com[^ ]*@$APT_MIRROR@g" \
    #    /etc/apt/sources.list

    sudo apt-get update

    # Update Python SSL libraries

    sudo apt-get -y install gcc libffi-dev libssl-dev python-dev
else
    sudo yum -y update
    sudo yum -y install gcc libffi-devel libssl-devel openssl-devel python-devel

fi

# Install pip
wget --quiet https://bootstrap.pypa.io/get-pip.py
sudo -H python get-pip.py

sudo -H $(which pip) install --upgrade ndg-httpsclient
sudo -H $(which pip) install awscli

# Set defaults on AWS configuration

EC2_REGION=$(cat region.txt | cut -d'"' -f 4)

echo "

$EC2_REGION
json" | aws configure