
from __future__ import print_function
from aws_base import *
from aws_request import *
from datetime import date, datetime, timedelta
import numpy
import pandas
import sys
import time

target_prices = None

"""
Return the desirabled price for spot instance requests. Note that while this
suggests that we may use it as a bid price, the on-demand price is the more
likely value, as the target price is viewed more as a nice-to-have.
"""
def get_target_prices():
    global target_prices

    if target_prices is not None:
        return target_prices

    on_demand_prices = get_on_demand_prices()

    target_prices = {}

    for instance_type, price in on_demand_prices.items():
        if instance_type.find('t2.') == 0:
            continue

        multiplier = 0.1

        if instance_type.find('.medium') == 2:
            multiplier = 0.3
        elif instance_type.find('.large') == 2:
            multiplier = 0.3
        elif instance_type.find('.xlarge') == 2:
            multiplier = 0.25
        elif instance_type.find('.2xlarge') == 2:
            multiplier = 0.25
        elif instance_type.find('.4xlarge') == 2:
            multiplier = 0.2
        elif instance_type.find('.8xlarge') == 2:
            multiplier = 0.2

        target_prices[instance_type] = round(price * multiplier, 3)

    return target_prices

"""
Utility method which retrieves the AWS EC2 price history for the given instance
type in the given availability zone over the last given number of days.
"""
def get_zone_price_history(instance_type, availability_zone, day_count):

    # Compute the start and end times based on day count

    today = date.today()
    today = datetime(today.year, today.month, today.day)

    end_time = today + timedelta(1)
    start_time = today + timedelta(0 - day_count)

    # Construct the time strings to pass to AWS CLI

    date_format = '%Y-%m-%dT%H:%M:%S.%fZ'
    start_time_string = datetime.strftime(start_time, date_format)
    end_time_string = datetime.strftime(end_time, date_format)

    # Retrieve the price history from AWS CLI

    price_list = aws(
        'ec2', 'describe-spot-price-history',
        '--product-descriptions', 'Linux/UNIX',
        '--instance-type', instance_type,
        '--availability-zone', availability_zone,
        '--start-time', start_time_string,
        '--end-time', end_time_string)

    # Parse the times and prices from the spot price history

    price_history = price_list['SpotPriceHistory']

    history_dates = numpy.array([
        datetime.strptime(price['Timestamp'], date_format)
            for price in price_history
    ])

    history_prices = numpy.array([
        float(price['SpotPrice']) for price in price_history
    ])

    return {
        'dates': history_dates,
        'prices': history_prices
    }

zone_list = None

"""
Utility method which retrieves the AWS EC2 price history for the given instance
type across all availability zones in the current region over the last given
number of days.
"""
def get_region_price_history(instance_type, day_count):
    global region, zone_list

    if zone_list is None:
        zone_list = aws(
            'ec2', 'describe-availability-zones', '--filter',
            'Name=region-name,Values=%s' % region)

    zones = zone_list['AvailabilityZones']
    zone_names = sorted([
        zone['ZoneName'] for zone in zones if zone['State'] == 'available'
    ])

    return [
        (zone_name, get_zone_price_history(instance_type, zone_name, day_count))
            for zone_name in zone_names
    ]

"""
Automatically select an availability zone based on the instance price history.
"""
def choose_availability_zone(instance_type, instance_price_history, target_price = None):
    if target_price is None:
        target_price = get_target_prices()[instance_type]

    demand_price = get_on_demand_prices()[instance_type]

    desired_zone_name = None
    desired_zone_stats = (100.0, 100.0, sys.float_info.max)

    historic_prices = {}

    for zone_name, price_history in instance_price_history:

        # Add information for the summary table

        max_zone_price = max(price_history['prices'])

        exceed_target = numpy.mean(price_history['prices'] > target_price)
        exceed_demand = numpy.mean(price_history['prices'] > demand_price)

        target_string = '%0.2f%%' % (100.0 * exceed_target)
        demand_string = '%0.2f%%' % (100.0 * exceed_demand)

        historic_prices[zone_name] = {
            'Maximum Price': max_zone_price,
            'Exceeded Target Bid': target_string,
            'Exceeded On-Demand Price': demand_string
        }

        # Identify the zone with the best target bid ratio, with tie-breakers
        # choosing the zone with the better within demand ratio, with more
        # tie-breakers choosing the one with the better maximum price.

        zone_stats = (exceed_target, exceed_demand, max_zone_price)

        if zone_stats < desired_zone_stats:
            desired_zone_name = zone_name
            desired_zone_stats = zone_stats

    df = pandas.DataFrame.from_dict(historic_prices, orient = 'index')
    df = df.reindex(columns = [
        'Exceeded Target Bid',
        'Exceeded On-Demand Price',
        'Maximum Price'
    ])

    return (df, desired_zone_name)

"""
Extension of an InstanceRequest which works with spot instance requests.
"""
class SpotInstanceRequest(InstanceRequest):

    """
    Utility method to check on the status of active spot instance requests.
    """
    def get_active(self):
        known_requests = aws('ec2', 'describe-spot-instance-requests')

        active_requests = {}

        for request in known_requests:
            if request['State'] in ['canceled', 'closed', 'failed']:
                continue

            if 'SpotInstanceRequestId' not in request:
                continue

            request_id = request['SpotInstanceRequestId']

            request_summary = {
                'created': request['CreateTime'],
                'updated': request['Status']['UpdateTime'],
                'status': request['Status']['Code'],
            }

            active_requests[request_id] = request_summary

        return active_requests

    """
    Issues a request for spot instances at the given bid price and with the
    given number of cluster nodes.
    """
    def make_request(self, bid_price, cluster_size):
        return aws(
            'ec2', 'request-spot-instances', '--spot-price', bid_price,
            '--instance-count', cluster_size, '--type', 'one-time',
            '--launch-specification', 'file://' + self.specification_file_name)

    """
    Retrieve the instance IDs that are associated with the given response for a
    spot instance request. This will wait until all spot requests are fulfilled
    and return all associated instance IDs.
    """
    def get_instance_ids(self, response):
        sir_response = response['SpotInstanceRequests']
        spot_request_ids = [
            response['SpotInstanceRequestId'] for response in sir_response
        ]

        fulfilled_instance_ids = self.get_fulfilled_instance_ids(
            spot_request_ids)

        while len(spot_request_ids) != len(fulfilled_instance_ids):
            time.sleep(15)
            fulfilled_instance_ids = self.get_fulfilled_instance_ids(
                spot_request_ids)

        return fulfilled_instance_ids

    """
    Utility method to check on the status of fulfilled spot instance requests.
    """
    def get_fulfilled_instance_ids(self, spot_request_ids):
        spot_requests_json = aws(
            'ec2', 'describe-spot-instance-requests',
            '--spot-instance-request-ids', *spot_request_ids)

        spot_requests = spot_requests_json['SpotInstanceRequests']

        # Log the status of spot requests.

        for request in spot_requests:
            status = request['Status']
            print('%s: %s' % (request['SpotInstanceRequestId'], status['Message']))

        # Now we look at all the fulfilled spot request instances and check to
        # see which ones are actually running.

        spot_requests_instance_ids = [
            request['InstanceId'] for request in spot_requests
                if request['Status']['Code'] != 'pending-fulfillment' and
                    request['Status']['Code'] != 'pending-evaluation'
        ]

        return spot_requests_instance_ids

